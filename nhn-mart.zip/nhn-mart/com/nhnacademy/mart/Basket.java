package com.nhnacademy.mart;

import java.util.ArrayList;

public class Basket {
    private final ArrayList<Food> foods = new ArrayList<>();

    // TODO 05 장바구니에 물건을 담는 메서드를 작성하세요.

    // TODO 06 장바구니에 있는 물건들을 반환하는 메서드를 작성하세요.

}
